"""Tests for Holiday Hangman functions."""

import sys
sys.path.append('my_module')
from functions import *

def test_choose_word():
    
    possible_words = ['santa', 'reindeer', 'elf', 'jingle', 
                      'sleigh', 'christmas', 'presents', 
                      'peppermint', 'ornament', 'stocking', 
                      'rudolf', 'snowflake', 'gingerbread', 
                      'snow', 'wreath', 'carol', 'eggnog', 
                      'mistletoe', 'tree', 'family']
    
    assert isinstance(choose_word(possible_words), str)
    assert choose_word(possible_words) in possible_words

def test_display():
    """Smoke test to check that the display function runs. 
    
    Note: there is not testing of accuracy / doing the right thing here. 
    """
    
    ADDING_PARTS = ['''

    -------
    |   |
    |
    |
    |
    |
  --------- ''', '''

    -------
    |   |
    |   O
    |
    |
    |
  --------- ''', '''

    -------
    |   |
    |   O
    |   X
    |   
    |
  --------- ''', '''

    -------
    |   |
    |   O
    |  (X
    |
    |
  --------- ''', '''

    -------
    |   |
    |   O
    |  (X)
    |
    |
  --------- ''', '''

    -------
    |   |
    |   O
    |  (X)
    |   l
    |
  --------- ''', '''

    -------
    |   |
    |   O
    |  (X)
    |   ll
    |
  --------- ''']
    
    wrong_guesses = 'abc'
    correct_guesses = 'def'
    puzzle_word = 'snow'
    
    display(ADDING_PARTS, wrong_guesses, correct_guesses, puzzle_word)
    assert True

def test_check_guess():
    """Test to see if check_guess screens out unacceptable guesses."""
    
    past_guesses = 'cdk'
    
    assert check_guess('2', past_guesses) == False
    assert check_guess('!', past_guesses) == False
    assert check_guess('aj', past_guesses) == False
    assert check_guess('k', past_guesses) == False
    assert check_guess('j', past_guesses) == True