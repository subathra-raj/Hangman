"""Functions necessary for Holiday Hangman."""

def choose_word(words):
    """Randomly choose a mystery word from the possible word list.
    
    Parameters
    ----------
    words: list
        List of possible words.
        
    Returns
    -------
    random_word: string
        Randomly chosen mystery word.
    """
    
    import random
    
    random_word = random.choice(words)
    
    return random_word

def display(ADDING_PARTS, wrong_guesses, correct_guesses, puzzle_word):
    """Display current game status.
    
    Parameters
    ----------
    ADDING_PARTS: list
        List of possible Hangman images.
    wrong_guesses: string
        Past incorrect guesses.
    correct_guesses: string
        Past correct guesses.
    puzzle_word: string
        Word that player is trying to guess.
    """
    
    #is slots a parameter?
    #what are my returns for this?
    
    #display physical state of hangman 
    if len(wrong_guesses) < len(ADDING_PARTS):
        print (ADDING_PARTS[len(wrong_guesses)])
        
    print ('Wrong Guesses: ' + wrong_guesses)

    slots = '_' * len(puzzle_word)
    
    #update slots to include correct guesses 
    for value in range(len(puzzle_word)):
        if puzzle_word[value] in correct_guesses:
            slots = slots[:value] + puzzle_word[value] + slots[value + 1:]
            
    #display empty and correctly guessed slots
    for letter in slots: 
        print (letter + ' ')
        

def ask_for_guess(past_guesses):
    """Ask player for one guess at a time. 
    
    Parameters
    ----------
    past_guesses: string
        Past guesses that the player cannot try to guess again.
    
    Returns
    -------
    guess: string
        Guess that is a lowercase single letter.
    """
    
    good = False
    while not good:
        guess = input('Guess a letter :\t')
        guess = guess.lower()
        good = check_guess(guess, past_guesses)

    return guess
        
def check_guess(guess, past_guesses):
    """   Check whether guess is a single alphabetic character. 
    
    Parameters
    ----------
    guess: string
        Player's inputted guess. 
    past_guesses: string 
        Player's past correct and incorrect guesses.
    
    Returns
    -------
    good: boolean
        Whether guess is an acceptable guess of a single letter.
    """
    
    if len(guess) != 1:
        print ('You can only guess one letter at a time. Please try again.')
        good = False
    elif guess in past_guesses:
        print ('You have already guessed this letter. Please try again.')
        good = False
    elif guess not in 'abcdefghijklmnopqrstuvwxyz':
        print ('You can only guess leters. Please try again.')
        good = False
    else:
        good = True
        
    return good
